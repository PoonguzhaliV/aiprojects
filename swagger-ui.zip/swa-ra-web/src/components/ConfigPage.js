import React from 'react';

function ConfigPage() {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Configuration</h2>
      <p>Place your configuration settings here in the future.</p>
    </div>
  );
}

export default ConfigPage;