package context;

import pojos.CreateResponse;

public class CreateResponseContext {

    private CreateResponse createResponse;

    public CreateResponse getCreateResponse() {
        return createResponse;
    }

    public void setCreateResponse(CreateResponse createResponse) {
        this.createResponse = createResponse;
    }
}
