package steps;

import org.testng.Assert;

import context.CreateResponseContext;
import io.cucumber.java.en.Then;

public class ResponseSteps {
	
	private final CreateResponseContext context;

    public ResponseSteps(CreateResponseContext context) {
        this.context = context;
    }
	
    @Then("the response status should be {int}")
    public void theResponseStatusShouldBe(int statusCode) {
        Assert.assertEquals(context.getCreateResponse().getStatusCode(), statusCode, "Expected status code mismatch");
    }


}
