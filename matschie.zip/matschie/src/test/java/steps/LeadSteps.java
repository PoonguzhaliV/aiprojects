
package steps;

import api.LeadAPI;
import context.CreateResponseContext;
import pojos.CreateLeadRequest;
import pojos.CreateResponse;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.testng.Assert;
import com.github.javafaker.Faker;

public class LeadSteps {
    private LeadAPI leadAPI;
    private CreateLeadRequest leadRequest;
    private final CreateResponseContext context;
    private CreateResponse createResponse;
    private Faker faker = new Faker();
    
    public LeadSteps(CreateResponseContext context) { 
        this.context = context; 
    } 
    
    @Given("I have valid lead details")
    public void iHaveValidLeadDetails() {
        leadAPI = new LeadAPI();
        leadRequest = new CreateLeadRequest();
        leadRequest.setFirstName(faker.name().firstName());
        leadRequest.setLastName(faker.name().lastName());
        leadRequest.setCompany(faker.company().name());
        leadRequest.setEmail(faker.internet().emailAddress());
        leadRequest.setPhone(faker.phoneNumber().phoneNumber());
    }
    
    @When("I create a new lead")
    public void iCreateANewLead() {
        createResponse = leadAPI.createLead(leadRequest);
        Assert.assertNotNull(createResponse.getId(), "Lead id should not be null");
        context.setCreateResponse(createResponse);
    }
}
