
package api;

import io.restassured.response.Response;
import pojos.CreateLeadRequest;
import pojos.CreateResponse;

public class LeadAPI extends BaseAPI {
    private static final String LEAD_ENDPOINT = "/Lead";
    
    // Create Lead
    public CreateResponse createLead(CreateLeadRequest request) {
        String endpoint = baseUrl + LEAD_ENDPOINT;
        Response response = post(endpoint, request, getAuthHeaders());
        try {
            CreateResponse createResponse = mapper.readValue(response.asString(), CreateResponse.class);
            createResponse.setStatusCode(response.getStatusCode());
            return createResponse;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse Create Lead response", e);
        }
    }
}
